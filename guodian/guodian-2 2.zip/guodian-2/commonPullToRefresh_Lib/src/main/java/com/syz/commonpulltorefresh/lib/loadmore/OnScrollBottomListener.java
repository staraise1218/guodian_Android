package com.syz.commonpulltorefresh.lib.loadmore;

public interface OnScrollBottomListener {
	public void onScorllBootom();
}

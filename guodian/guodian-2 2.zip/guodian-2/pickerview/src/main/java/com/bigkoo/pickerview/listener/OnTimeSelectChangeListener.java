package com.bigkoo.pickerview.listener;

import java.util.Date;

/**
 * Created by xiaosong on 2018/3/20.
 */

public interface OnTimeSelectChangeListener {

    void onTimeSelectChanged(Date date);
}

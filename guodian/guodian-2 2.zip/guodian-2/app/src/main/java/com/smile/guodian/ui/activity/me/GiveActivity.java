package com.smile.guodian.ui.activity.me;

import com.smile.guodian.ui.activity.BaseActivity;

public class GiveActivity extends BaseActivity {
    @Override
    protected void init() {

    }

    @Override
    protected int getContentResourseId() {
        return 0;
    }
}

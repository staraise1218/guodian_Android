package com.smile.guodian.base;


public class BundleKey {

    public static final String PARCELABLE = "parcelable";
}

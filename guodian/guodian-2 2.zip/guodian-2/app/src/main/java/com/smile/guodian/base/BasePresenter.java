package com.smile.guodian.base;


public interface BasePresenter {
    void start();
}

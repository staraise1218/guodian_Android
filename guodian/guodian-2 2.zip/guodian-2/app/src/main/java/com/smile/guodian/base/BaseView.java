package com.smile.guodian.base;


public interface BaseView {
    void initView();
}

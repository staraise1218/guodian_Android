package com.smile.guodian.base;


public class Constants {

    /**
     * 缓存文件保存路径
     */
    public static final String CACHE_FILE_PATH = "/smile/cache/";
}

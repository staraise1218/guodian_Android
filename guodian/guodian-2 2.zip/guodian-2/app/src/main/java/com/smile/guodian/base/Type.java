package com.smile.guodian.base;


public class Type {

    public final static int TYPE_SHOW = 0;
    public final static int TYPE_FOOTER_LOAD = 1;
    public final static int TYPE_FOOTER_FULL = 2;
}

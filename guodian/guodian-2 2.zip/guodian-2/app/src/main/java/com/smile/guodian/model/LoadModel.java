package com.smile.guodian.model;

import com.smile.guodian.presenter.OnLoadListener;


public interface LoadModel {
    void load(OnLoadListener listener);
}

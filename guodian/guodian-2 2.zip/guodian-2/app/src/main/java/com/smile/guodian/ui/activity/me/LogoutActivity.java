package com.smile.guodian.ui.activity.me;

import com.smile.guodian.R;
import com.smile.guodian.ui.activity.BaseActivity;

public class LogoutActivity extends BaseActivity {
    @Override
    protected void init() {

    }

    @Override
    protected int getContentResourseId() {
        return R.layout.activity_logout;
    }
}
